# Data Science Interview Questions

* Theoretical questions: [theory.md](theory.md)
